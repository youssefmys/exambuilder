function update_question_answer(select_id) {
  select_e = document.findElementById("exam_questions_attributes_" + select_id + "_type");
  if (select_e.selectedIndex == 1) {

  }
  if (select_e.selectedIndex == 2) {
  
  }
}
;
