function update_question_answer() {
  
}
;
